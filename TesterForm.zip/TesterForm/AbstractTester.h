// abstract class with virtual fnc
class AbstractTester{
public:
	// pure virtual fnc
	virtual void test() = 0;
	// contructor of class
	AbstractTester(int itemsCount, char scenario) {
		_itemsCount = itemsCount;
		_scenario = scenario;
	}

	char getScenario() {
		return _scenario;
	}

private:
	// definicia poctu operaci nad testom
	int _itemsCount;
	// ktory scenar si zavolame
	char _scenario;

};
