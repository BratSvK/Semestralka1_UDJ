#include "AbstractTester.h";
#include "structures/list/list.h";

using namespace structures;

class PriorityQueue : public AbstractTester {

public:
	PriorityQueue(List<int>* list, int itemsCount, char scenario) : AbstractTester(itemsCount, scenario) {
		_list = list;
	}

	~PriorityQueue() {
		delete _list;
	}


	void test();

private:
	// implementacia listu pre testy vseobecne
	List<int>* _list;
};



void PriorityQueue::test() {

}