#include "AbstractTester.h";
#include "structures/list/list.h";
#include <iostream>

using namespace std;
using namespace structures;

class ListTester : public AbstractTester {
	
public:
	ListTester(List<int>* list, int itemsCount, char scenario): AbstractTester(itemsCount,scenario) {
		_list = list; 
	}

	~ListTester() {
		delete _list;
	}

	

	void test();

private:
	// implementacia listu pre testy vseobecne
	List<int>* _list; 
	void ScenarA();
	void ScenarB();
	void ScenarC();

};


// vykonavanie samotneho testu podla scenarov
void ListTester::test() {
	
	switch (tolower(this->getScenario()))
	{
	case 'a':
		this->ScenarA();
	case 'b': 
		this->ScenarB();
	case 'c':
		this->ScenarC();
	default:
		break;
	}
}


// funckie pre scenare podla uzivatela sa doplni casom 
void ListTester::ScenarA() {
	cout << "Ahoj";
}


void ListTester::ScenarB() {

}

void ListTester::ScenarC() {

}